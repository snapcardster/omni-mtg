
Make sure to place the latest version of omni-mtg.jar into the omni-mtg-java-archive folder.
You can download it here:
https://github.com/snapcardster/omni-mtg/blob/master/target/scala-2.12/omni-mtg.jar

More information at:
https://github.com/snapcardster/omni-mtg
