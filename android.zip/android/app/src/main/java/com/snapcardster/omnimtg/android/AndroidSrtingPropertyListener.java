package com.snapcardster.omnimtg.android;

public interface AndroidSrtingPropertyListener {
    void onChanged(String oldValue, String newValue, Boolean callListener);
}
