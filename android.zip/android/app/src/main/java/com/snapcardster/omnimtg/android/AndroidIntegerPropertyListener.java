package com.snapcardster.omnimtg.android;

public interface AndroidIntegerPropertyListener {
    void onChanged(Integer oldValue, Integer newValue, Boolean callListener);
}
